﻿using HorseRacingClient;
using HorseRacingClient.ServiceModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HorseRacingClient.ClientInterface;
using HorseRacingClient.ClientModel;

namespace HorseRacing
{
    class Program
    {
        static void Main(string[] args)
        {
            HorseRacingClient.ClientInterface.Race race = new HorseRacingClient.ClientInterface.Race();
            List<HorseRacingClient.ClientModel.Race> allRaces = race.GetRaces();

            allRaces.ForEach(currentRace => 
            {
                Console.WriteLine("-----------------------------------------------");
                Console.WriteLine(currentRace.Status + "\t" + currentRace.Stake);

                Console.WriteLine("--------------------Horses---------------------");
                if (currentRace.Horses != null)
                {
                    currentRace.Horses.ForEach(currentHorse => 
                    {
                        Console.WriteLine(currentHorse.Name + "\t" + currentHorse.NumberOfBets + "\t" + currentHorse.MoneyPayOut);
                    });
                }
                Console.WriteLine("-----------------------------------------------");
            });

            HorseRacingClient.Bet bet = new HorseRacingClient.Bet();
            Bets bets = bet.GetBettings();

            Console.ReadLine();
        }
    }
}
