﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient
{
    internal class ClientMessageInspector : DelegatingHandler
    {
        public ClientMessageInspector(HttpMessageHandler innerHandler) : base(innerHandler)
        {
        }
        protected async override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
           System.Threading.CancellationToken cancellationToken)
        {
            // Add logging here

            // Add headers in the request here

            // Get the response
            HttpResponseMessage response = null;
            response = await base.SendAsync(request, cancellationToken);
            return response;
        }
    }
}
