﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient
{
    internal class APIClient
    {
        public T GetResponse<T>(string url)
        {
            string response = string.Empty;

            ClientMessageInspector clientHandler = new ClientMessageInspector(new HttpClientHandler());
            HttpClient client = new HttpClient(clientHandler);
            HttpResponseMessage httpResponse = client.GetAsync(url).Result;
            if (httpResponse.IsSuccessStatusCode)
            {
                var responseContent = httpResponse.Content;

                response = responseContent.ReadAsStringAsync().Result;
            }
            T genericType = JsonConvert.DeserializeObject<T>(response);
            return genericType;
        }
    }
}
