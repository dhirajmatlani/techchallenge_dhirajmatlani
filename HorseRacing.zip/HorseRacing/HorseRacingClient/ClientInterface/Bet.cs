﻿using HorseRacingClient.ClientModel;
using HorseRacingClient.ServiceInterface;
using HorseRacingClient.ServiceModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HorseRacingClient
{
    public class Bet
    {
        public Bets GetBettings()
        {
            CustomerClient customerClient = new CustomerClient();
            List<Customer> customers = customerClient.GetCustomers();

            BetClient betClient = new BetClient();
            List<ServiceModel.Bet> bettings = betClient.GetBets();

            Bets bets = new Bets();
            bets.Bettings = new List<CustomerBet>();

            if (customers != null)
            {
                customers.ForEach(customer =>
                {
                    if (bettings != null)
                    {
                        List<ServiceModel.Bet> allBets = bettings.FindAll(bet => bet.CustomerId == customer.Id);
                        if (allBets != null)
                        {
                            CustomerBet customerBet = new CustomerBet();
                            customerBet.CustomerId = customer.Id;
                            customerBet.BetCount = allBets.Count;
                            customerBet.BetAmount = allBets.Sum(item => item.Stake);
                            customerBet.IsRisky = allBets.Exists(item => item.Stake > 200);
                            bets.Bettings.Add(customerBet);
                        }
                    }
                });
            }

            if (bettings != null)
            {
                bets.ToTalBetAmount = bettings.Sum(item => item.Stake);
            }

            return bets;
        }
    }
}
