﻿using HorseRacingClient.ClientModel;
using HorseRacingClient.ServiceInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HorseRacingClient.ClientModel;

namespace HorseRacingClient.ClientInterface
{
    public class Race
    {
        public List<ClientModel.Race> GetRaces()
        {
            RaceClient raceClient = new RaceClient();
            List<ServiceModel.Race> allRaces = raceClient.GetRaces();

            BetClient betClient = new BetClient();
            List<ServiceModel.Bet> bettings = betClient.GetBets();

            List<ClientModel.Race> races = new List<ClientModel.Race>();

            if (allRaces != null)
            {
                allRaces.ForEach(currentRace =>
                {
                    ClientModel.Race race = new ClientModel.Race();
                    race.Horses = new List<Horse>();

                    race.Status = currentRace.Status;

                    if (bettings != null)
                    {
                        race.Stake = bettings.FindAll(bet => bet.RaceId == currentRace.Id).Sum(itemBet => itemBet.Stake);
                    }

                    if (currentRace.Horses != null)
                    {
                        currentRace.Horses.ForEach(currentHorse =>
                        {
                            Horse horse = new Horse();
                            horse.Name = currentHorse.Name;

                            if (bettings != null)
                            {
                                horse.MoneyPayOut = bettings.FindAll(bet => bet.RaceId == currentRace.Id && bet.HorseId == currentHorse.Id).Sum(item => item.Stake) * currentHorse.Odds;
                                horse.NumberOfBets = bettings.Count(bet => bet.RaceId == currentRace.Id && bet.HorseId == currentHorse.Id);
                                race.Horses.Add(horse);
                            }
                        });
                    }
                    races.Add(race);
                });
            }                   
            return races;
        }
    }
}
