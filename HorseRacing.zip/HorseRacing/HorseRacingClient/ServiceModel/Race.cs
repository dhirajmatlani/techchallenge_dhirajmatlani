﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient.ServiceModel
{
    public class Race
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Start { get; set; }
        public string Status { get; set; }
        public List<Horse> Horses { get; set; }

    }

    public class Horse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Odds { get; set; }

    }
}
