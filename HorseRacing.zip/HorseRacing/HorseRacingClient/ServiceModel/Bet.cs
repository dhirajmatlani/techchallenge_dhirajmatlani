﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient.ServiceModel
{
    public class Bet
    {
        public int CustomerId { get; set; }
        public int HorseId {get; set;}
        public int RaceId { get; set; }
        public decimal Stake { get; set; }
    }
}
