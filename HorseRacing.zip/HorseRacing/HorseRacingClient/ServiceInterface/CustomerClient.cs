﻿using HorseRacingClient.ServiceModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient.ServiceInterface
{
    public class CustomerClient
    {
        public List<Customer> GetCustomers()
        {
            string url = "https://whatech-customerbets.azurewebsites.net/api/GetCustomers?name={0}";
            APIClient apiClient = new APIClient();
            List<Customer> customers = apiClient.GetResponse<List<Customer>>(string.Format(url, "dhiraj.matlani"));
            return customers;
        }
    }
}
