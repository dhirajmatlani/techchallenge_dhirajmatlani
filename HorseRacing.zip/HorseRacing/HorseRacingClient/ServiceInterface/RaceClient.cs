﻿using HorseRacingClient.ServiceModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient.ServiceInterface
{
    public class RaceClient
    {
        public List<Race> GetRaces()
        {
            string url = "https://whatech-customerbets.azurewebsites.net/api/GetRaces?name={0}";
            APIClient apiClient = new APIClient();
            List<Race> races = apiClient.GetResponse<List<Race>>(string.Format(url, "dhiraj.matlani"));
            return races;
        }
    }
}
