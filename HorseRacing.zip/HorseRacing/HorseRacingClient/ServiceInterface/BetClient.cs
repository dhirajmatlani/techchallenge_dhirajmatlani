﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HorseRacingClient.ServiceModel;

namespace HorseRacingClient.ServiceInterface
{
    public class BetClient
    {
        public List<ServiceModel.Bet> GetBets()
        {
            string url = "https://whatech-customerbets.azurewebsites.net/api/GetBetsV2?name={0}";
            APIClient apiClient = new APIClient();
            List<ServiceModel.Bet> bets = apiClient.GetResponse<List<ServiceModel.Bet>>(string.Format(url, "dhiraj.matlani"));
            return bets;
        }
    }
}
