﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient.ClientModel
{
    public class CustomerBet
    {
        public int CustomerId { get; set; }
        public int BetCount { get; set; }
        public decimal BetAmount { get; set; }
        public bool IsRisky { get; set; }
    }

    public class Bets
    {
        public List<CustomerBet> Bettings { get; set; }

        public decimal ToTalBetAmount { get; set; }
    }
}
