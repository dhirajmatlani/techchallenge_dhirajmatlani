﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseRacingClient.ClientModel
{
    public class Race
    {
        public string Status { get; set; }
        public decimal Stake { get; set; }
        public List<Horse> Horses { get; set; }
    }

    public class Horse
    {
        public string Name { get; set; }
        public int NumberOfBets { get; set; }
        public decimal MoneyPayOut { get; set; } 

    }
}
